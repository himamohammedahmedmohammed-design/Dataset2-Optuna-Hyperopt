# House Price Prediction — End-to-End ML Web App

A complete student project for house-price prediction using the Kaggle House Price dataset by Juhi Bhojani. The project contains a reproducible notebook, trained scikit-learn pipeline, FastAPI backend, React + TypeScript frontend, tests, and Docker support.

## Results

The supplied dataset contains **187,531 rows and 21 columns**. After parsing, missing-value handling, feature engineering, and 1st–99th percentile price-per-square-foot filtering, **98,069 rows** remained.

| Model | MAE (₹) | RMSE (₹) | R² |
|---|---:|---:|---:|
| LinearRegression | 4,575,554 | 7,498,429 | 0.7183 |
| HistGradientBoostingRegressor | **1,606,619** | **4,625,698** | **0.8928** |

Winner: **HistGradientBoostingRegressor**.

## Architecture

`React form → FastAPI /api/predict → saved scikit-learn Pipeline → predicted price`

## Tech Stack

- Python 3.11
- pandas / NumPy / scikit-learn
- Jupyter
- FastAPI + Pydantic
- React + TypeScript + Vite
- pytest
- Docker

## Dataset

Kaggle: https://www.kaggle.com/datasets/juhibhojani/house-price

Download the dataset and put `house_prices.csv` at `notebooks/data/house_prices.csv`. Do not commit the raw CSV to GitHub.

## Project Structure

```text
notebooks/house_price_model.ipynb
notebooks/data/house_prices.csv       # local only
backend/app/
backend/models/house_price.pkl
backend/models/locations.json
backend/tests/
frontend/src/
README.md
```

## Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://localhost:8000/docs.

Endpoints:
- `GET /api/health`
- `POST /api/predict`

Example:

```bash
curl -X POST http://localhost:8000/api/predict \
  -H "Content-Type: application/json" \
  -d '{"location":"thane","carpet_area_sqft":900,"floor_num":5,"bathroom":2,"balcony":1,"furnishing":"Semi-Furnished","transaction":"Resale","ownership":"Freehold","facing":"East"}'
```

## Backend Tests

```bash
cd backend
pytest
```

## Frontend

```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

For macOS/Linux use `cp .env.example .env`.

The frontend uses `VITE_API_BASE_URL`, defaulting to `http://localhost:8000`.

## Notebook

Start Jupyter from the `notebooks` directory:

```bash
jupyter notebook
```

Open `house_price_model.ipynb`, then **Kernel → Restart & Run All**.

## Docker

```bash
docker compose up --build
```

## GitHub

Create a public GitHub repository, then:

```bash
git init
git add .
git commit -m "House price prediction: notebook, FastAPI backend, React frontend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/house-price-app.git
git push -u origin main
```

Before pushing, verify that `.gitignore` excludes `.venv`, `node_modules`, `.env`, logs, and the raw CSV.

## Screenshots

Run the backend and frontend locally and add screenshots of the form and prediction result here before final submission.

