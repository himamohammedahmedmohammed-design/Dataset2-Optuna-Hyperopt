from fastapi import APIRouter, Request
from app.schemas.prediction import PredictionRequest, PredictionResponse
from app.services.preprocessing import request_to_frame

router = APIRouter()

@router.get("/health")
def health(request: Request):
    return {"status": "ok", "model_loaded": request.app.state.model is not None}

@router.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest, request: Request):
    frame = request_to_frame(payload)
    prediction = float(request.app.state.model.predict(frame)[0])
    return PredictionResponse(predicted_price=max(0.0, prediction))
