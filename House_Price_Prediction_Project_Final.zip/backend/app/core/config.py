from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    api_title: str = "House Price Prediction API"

settings = Settings()
