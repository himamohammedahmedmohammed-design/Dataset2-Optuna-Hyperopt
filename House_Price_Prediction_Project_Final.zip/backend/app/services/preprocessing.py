import pandas as pd
from app.schemas.prediction import PredictionRequest

def request_to_frame(payload: PredictionRequest) -> pd.DataFrame:
    return pd.DataFrame([{
        "carpet_area_sqft": payload.carpet_area_sqft,
        "floor_num": payload.floor_num,
        "bathroom": payload.bathroom,
        "balcony": payload.balcony,
        "location_grouped": payload.location,
        "Furnishing": payload.furnishing,
        "Transaction": payload.transaction,
        "Ownership": payload.ownership,
        "facing": payload.facing,
    }])
