import pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

def test_health(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_invalid_prediction(client):
    response = client.post("/api/predict", json={
        "location": "thane", "carpet_area_sqft": -1, "floor_num": 2,
        "bathroom": 2, "balcony": 1, "furnishing": "Unfurnished",
        "transaction": "Resale", "ownership": "Freehold", "facing": "East"
    })
    assert response.status_code == 422

def test_prediction(client):
    response = client.post("/api/predict", json={
        "location": "thane", "carpet_area_sqft": 900, "floor_num": 5,
        "bathroom": 2, "balcony": 1, "furnishing": "Semi-Furnished",
        "transaction": "Resale", "ownership": "Freehold", "facing": "East"
    })
    assert response.status_code == 200
    assert response.json()["predicted_price"] > 0
