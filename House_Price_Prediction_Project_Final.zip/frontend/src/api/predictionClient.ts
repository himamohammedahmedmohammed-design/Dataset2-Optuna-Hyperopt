import type { PredictionRequest, PredictionResponse } from "../types/prediction";

const API = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

export async function predictPrice(payload: PredictionRequest): Promise<PredictionResponse> {
  const res = await fetch(`${API}/api/predict`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Prediction request failed");
  }
  return res.json();
}
