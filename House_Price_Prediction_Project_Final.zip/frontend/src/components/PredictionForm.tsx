import { useState } from "react";
import type { PredictionRequest } from "../types/prediction";
import { predictPrice } from "../api/predictionClient";

const locations = ["agra", "ahmedabad", "allahabad", "aurangabad", "badlapur", "bangalore", "bhiwadi", "bhubaneswar", "chandigarh", "chennai", "coimbatore", "dehradun", "faridabad", "ghaziabad", "goa", "greater-noida", "guntur", "gurgaon", "guwahati", "hyderabad", "jaipur", "jamshedpur", "kalyan", "kanpur", "kochi", "kolkata", "lucknow", "mangalore", "mohali", "mumbai", "nagpur", "nashik", "navi-mumbai", "new-delhi", "noida", "palghar", "panchkula", "patna", "pune", "raipur", "ranchi", "siliguri", "sonipat", "surat", "thane", "vadodara", "varanasi", "vijayawada", "visakhapatnam", "zirakpur"];

const defaults: PredictionRequest = {
  location: locations[0] || "Other", carpet_area_sqft: 900, floor_num: 3,
  bathroom: 2, balcony: 1, furnishing: "Semi-Furnished",
  transaction: "Resale", ownership: "Freehold", facing: "East"
};

export default function PredictionForm({onResult}: {onResult:(price:number)=>void}) {
  const [form,setForm] = useState(defaults);
  const [loading,setLoading] = useState(false);
  const [error,setError] = useState("");

  const set = (key:keyof PredictionRequest, value:string|number) =>
    setForm({...form,[key]:value});

  async function submit(e:React.FormEvent) {
    e.preventDefault(); setError("");
    if (form.carpet_area_sqft <= 0) { setError("Carpet area must be greater than 0."); return; }
    try { setLoading(true); const r=await predictPrice(form); onResult(r.predicted_price); }
    catch(err) { setError(err instanceof Error ? err.message : "Prediction failed."); }
    finally { setLoading(false); }
  }

  return <form onSubmit={submit}>
    <label>Location<select value={form.location} onChange={e=>set("location",e.target.value)}>{locations.map(x=><option key={x}>{x}</option>)}</select></label>
    <label>Carpet Area (sqft)<input type="number" min="1" value={form.carpet_area_sqft} onChange={e=>set("carpet_area_sqft",Number(e.target.value))}/></label>
    <label>Floor<input type="number" min="0" value={form.floor_num} onChange={e=>set("floor_num",Number(e.target.value))}/></label>
    <label>Bathrooms<input type="number" min="0" value={form.bathroom} onChange={e=>set("bathroom",Number(e.target.value))}/></label>
    <label>Balconies<input type="number" min="0" value={form.balcony} onChange={e=>set("balcony",Number(e.target.value))}/></label>
    <label>Furnishing<select value={form.furnishing} onChange={e=>set("furnishing",e.target.value)}><option>Furnished</option><option>Semi-Furnished</option><option>Unfurnished</option></select></label>
    <label>Transaction<select value={form.transaction} onChange={e=>set("transaction",e.target.value)}><option>New Property</option><option>Resale</option></select></label>
    <label>Ownership<select value={form.ownership} onChange={e=>set("ownership",e.target.value)}><option>Freehold</option><option>Leasehold</option><option>Power Of Attorney</option><option>Co-operative Society</option></select></label>
    <label>Facing<select value={form.facing} onChange={e=>set("facing",e.target.value)}><option>East</option><option>West</option><option>North</option><option>South</option><option>North-East</option><option>North-West</option><option>South-East</option><option>South-West</option></select></label>
    {error && <p className="error">{error}</p>}
    <button disabled={loading}>{loading ? "Predicting..." : "Predict Price"}</button>
  </form>
}
