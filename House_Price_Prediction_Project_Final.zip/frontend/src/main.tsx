import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import HomePage from "./pages/HomePage";
import ResultPage from "./pages/ResultPage";
import "./styles.css";
function App(){const [price,setPrice]=useState<number|null>(null);return price===null?<HomePage onResult={setPrice}/>:<ResultPage price={price} onBack={()=>setPrice(null)}/>}
createRoot(document.getElementById("root")!).render(<React.StrictMode><App/></React.StrictMode>);
