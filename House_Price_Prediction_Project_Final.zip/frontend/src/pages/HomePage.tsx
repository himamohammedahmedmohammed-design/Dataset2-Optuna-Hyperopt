import PredictionForm from "../components/PredictionForm";
export default function HomePage({onResult}:{onResult:(p:number)=>void}) {
  return <main><h1>House Price Predictor</h1><p>Enter property details to estimate the listing price.</p><PredictionForm onResult={onResult}/></main>
}
