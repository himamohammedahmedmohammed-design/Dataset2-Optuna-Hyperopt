export default function ResultPage({price,onBack}:{price:number,onBack:()=>void}) {
 return <main className="result"><h1>Estimated Price</h1><div className="price">₹ {price.toLocaleString("en-IN",{maximumFractionDigits:0})}</div><button onClick={onBack}>New Prediction</button></main>
}
