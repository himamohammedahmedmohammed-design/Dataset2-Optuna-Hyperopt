Put the downloaded Kaggle `house_prices.csv` here before running the notebook.
Raw CSV is intentionally excluded from the Git repository because the project guide says not to commit the large dataset.
